export declare function requestAndConnectWallet(): void;
export declare const visible: import("svelte/store").Writable<boolean>;
export declare function showPrompt(): void;
export declare function hidePrompt(): void;
