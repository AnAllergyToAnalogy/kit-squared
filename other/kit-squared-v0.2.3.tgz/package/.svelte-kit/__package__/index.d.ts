import { type NetworkType } from "./library/wallet.js";
export declare function init(http: string, ws: string, networkType?: NetworkType): void;
export { getNetworkType, getNetwork, getConnection, checkAccountExists, getAccountBalance } from "./library/connection.js";
export { onConnect, onDisconnect } from "./library/connectSchedule.js";
export { transacting, TRANSACTION_STATE, transactionState, onTransaction, clearAddedAccounts, addAccounts, getAddedAccounts, transact, createProgram, } from "./library/program.js";
export * from "./library/utils.js";
export { walletState, walletInitial, walletConnecting, walletConnected, walletError, signer, myKey, me, myKeyString, isMe, getStoredWalletSelection, disconnectWallet, unmountWallet } from "./library/wallet.js";
export { availableWallets, selection, selectWallet, getWalletInfo, unmountTeardown, recheckWallets, } from "./library/walletSelection.js";
