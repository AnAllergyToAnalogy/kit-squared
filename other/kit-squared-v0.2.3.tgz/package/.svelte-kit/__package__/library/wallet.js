import { writable, derived } from "svelte/store";
import { Event } from "./utils.js";
import { getNetworkType } from "./connection.js";
import { _selection, onSelectWallet, expectWallet, clearSelectedVars, unmountTeardown } from "./walletSelection.js";
import { clearStorage, readStorage, writeStorage } from "./utils.js";
import { getOrCreateUiWalletAccountForStandardWalletAccount_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, getWalletAccountForUiWalletAccount_DO_NOT_USE_OR_YOU_WILL_BE_FIRED, getWalletForHandle_DO_NOT_USE_OR_YOU_WILL_BE_FIRED } from "@wallet-standard/ui-registry";
import { getWalletAccountFeature, getWalletFeature } from "@wallet-standard/ui";
import { StandardConnect, StandardDisconnect } from "@wallet-standard/features";
import { SolanaSignAndSendTransaction } from "@solana/wallet-standard-features";
import { address } from "@solana/kit";
import { getTransactionEncoder } from "@solana/transactions";
import { getAbortablePromise } from "@solana/promises";
export const WALLET_STATE = {
    INITIAL: "INITIAL",
    CONNECTING: "CONNECTING",
    CONNECTED: "CONNECTED",
    ERROR: "ERROR",
};
const INITIAL = WALLET_STATE.INITIAL;
const CONNECTING = WALLET_STATE.CONNECTING;
const CONNECTED = WALLET_STATE.CONNECTED;
const ERROR = WALLET_STATE.ERROR;
export let walletState = writable(WALLET_STATE.INITIAL);
function _setWalletState(state) {
    walletState.set(state);
}
// Helper vars
export const walletInitial = derived(walletState, ($state) => {
    return $state === WALLET_STATE.INITIAL;
});
export const walletConnecting = derived(walletState, ($state) => {
    return $state === WALLET_STATE.CONNECTING;
});
export const walletConnected = derived(walletState, ($state) => {
    return $state === WALLET_STATE.CONNECTED;
});
export const walletError = derived(walletState, ($state) => {
    return $state === WALLET_STATE.ERROR;
});
export let signer;
export let myKey = null;
export let me = writable(myKey);
export let myKeyString = null;
export function isMe(address) {
    if (!address || !myKey)
        return false;
    return myKey.toString() === address.toString();
}
// Wallet Storage
function storeWalletSelection(name) {
    writeStorage("walletSelection", name);
}
export function getStoredWalletSelection() {
    return readStorage("walletSelection", null);
}
function clearStoredWalletSelection() {
    clearStorage("walletSelection");
}
//@ts-ignore
export let connectedWalletAccount = null;
//@ts-ignore
export let hasConnectedWalletAccount = writable(false);
//@ts-ignore
export let connectedWallet = null;
//@ts-ignore
export let hasConnectedWallet = writable(false);
function uiWalletAccountsAreSame(a, b) {
    if (a.address !== b.address) {
        return false;
    }
    const underlyingWalletA = getWalletForHandle_DO_NOT_USE_OR_YOU_WILL_BE_FIRED(a);
    const underlyingWalletB = getWalletForHandle_DO_NOT_USE_OR_YOU_WILL_BE_FIRED(b);
    return underlyingWalletA === underlyingWalletB;
}
async function connectWallet(uiWallet) {
    _setWalletState(CONNECTING);
    const wallet = getWalletForHandle_DO_NOT_USE_OR_YOU_WILL_BE_FIRED(uiWallet);
    // Accounts that are available?
    const existingAccounts = [...uiWallet.accounts];
    // Do some stuff to get the ability to connect
    const connectFeature = getWalletFeature(uiWallet, StandardConnect);
    // Wallet accounts for all the wallets in this connected one maybe
    const accountsPromise = connectFeature
        .connect()
        .then(({ accounts }) => {
        // console.log("connected", accounts);
        // return accounts;
        return accounts.map(getOrCreateUiWalletAccountForStandardWalletAccount_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.bind(null, wallet));
    });
    const nextAccounts = await accountsPromise;
    // Just set connectedWallet
    connectedWallet = uiWallet;
    hasConnectedWallet.set(true);
    // Try to choose the first never-before-seen account. Gonna assume this is the right move for now
    for (const nextAccount of nextAccounts) {
        if (!existingAccounts.some((existingAccount) => uiWalletAccountsAreSame(nextAccount, existingAccount))) {
            connectedWalletAccount = nextAccount;
            hasConnectedWalletAccount.set(true);
            _setWalletState(CONNECTED);
            return;
        }
    }
    if (nextAccounts.length > 0) {
        connectedWalletAccount = nextAccounts[0];
        hasConnectedWalletAccount.set(true);
        _setWalletState(CONNECTED);
        return;
    }
    console.error("No available wallets found for unspecified reason");
    _setWalletState(INITIAL);
}
export async function disconnectWallet() {
    clearStoredWalletSelection();
    clearSelectedVars();
    if (!connectedWallet) {
        //  connected wallet var empty. just clear vars.
        //   one or both expected account objects are missing
    }
    else {
        const disconnectFeature = getWalletFeature(connectedWallet, StandardDisconnect);
        await disconnectFeature.disconnect();
    }
    connectedWallet = null;
    hasConnectedWallet.set(false);
    connectedWalletAccount = null;
    hasConnectedWalletAccount.set(false);
    signer = null;
    myKey = null;
    me.set(null);
    _setWalletState(INITIAL);
    onWalletDisconnect.trigger();
}
function _buildTransactionSendingSigner(_networkType) {
    if (!connectedWalletAccount)
        throw new Error("connectedWalletAccount is null");
    const signAndSendTransactionFeature = getWalletAccountFeature(connectedWalletAccount, SolanaSignAndSendTransaction);
    const transactionSendingSigner = {
        address: address(connectedWalletAccount.address),
        async signAndSendTransactions(transactions, config = {}) {
            const { abortSignal, ...options } = config;
            abortSignal?.throwIfAborted();
            const transactionEncoder = getTransactionEncoder();
            if (transactions.length > 1) {
                //TODO: pretty sure this is just for this specific case
                throw new Error("should only have one transaction");
            }
            if (transactions.length === 0) {
                return [];
            }
            if (!connectedWalletAccount) {
                throw new Error("no connected wallet account");
            }
            const [transaction] = transactions;
            const wireTransactionBytes = transactionEncoder.encode(transaction);
            const walletAccount = getWalletAccountForUiWalletAccount_DO_NOT_USE_OR_YOU_WILL_BE_FIRED(connectedWalletAccount);
            let chain = `solana:${getNetworkType()}`;
            const inputWithOptions = {
                ...options,
                transaction: wireTransactionBytes,
                chain,
                account: walletAccount,
            };
            const [{ signature }] = await getAbortablePromise(signAndSendTransactionFeature.signAndSendTransaction(inputWithOptions), abortSignal);
            return Object.freeze([signature]);
        },
    };
    return transactionSendingSigner;
}
// Done by main init
export function initialiseWallet() {
    let networkType = getNetworkType();
    if (!networkType)
        throw new Error("Network not configured.");
    onSelectWallet(async () => {
        if (!_selection || !_selection.wallet)
            throw new Error("Wallet selection is null");
        // They just specified which wallet they are gonna use, it didn't connect. Connect is done else where
        // Connect wallet
        await connectWallet(_selection.wallet.uiWallet);
        signer = _buildTransactionSendingSigner(networkType);
        myKey = signer.address;
        myKeyString = signer.address;
        me.set(myKey.toString());
        // Update local storage
        storeWalletSelection(_selection.name);
        onWalletConnect.trigger();
    });
    initialWalletCheck();
}
export function unmountWallet() {
    unmountTeardown();
}
function initialWalletCheck() {
    //Called by walletSelection.ts after it first sees what wallets it has
    if (getStoredWalletSelection()) {
        expectWallet(getStoredWalletSelection());
    }
}
export const onWalletConnect = Event();
export const onWalletDisconnect = Event();
