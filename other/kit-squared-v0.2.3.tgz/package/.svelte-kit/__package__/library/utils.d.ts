import { type Address } from "@solana/kit";
export declare const ZERO_ADDRESS = "11111111111111111111111111111111";
export declare function integerTypeToSize(type: string): string;
export declare function isIntegerType(type: string): boolean;
export declare function isNumberType(type: string): boolean;
export declare const typeEncoder: {
    [key: string]: any;
};
export declare function address(str: string): any;
export declare function camelToSnake(name: string): string;
export declare function snakeToCamel(name: string): string;
export declare function pascalToCamel(name: string): string;
export declare function camelToPascal(name: string): string;
export declare function snakeToPascal(name: string): string;
export declare function pascalToSnake(name: string): string;
export interface Callback {
    (...args: any[]): void;
}
export interface EventSingleType {
    (callback: Callback): void;
    trigger: Function;
}
export declare function EventSingle(): EventSingleType;
export interface OnEvent {
    (...args: any[]): void;
}
export interface EventType {
    (callback: Callback): void;
    killAll: Function;
    trigger: Function;
}
export declare function Event(): {
    (callback: Callback): () => void;
    trigger: (...args: any[]) => Promise<void>;
    killAll: () => void;
};
export declare function getPDA(seeds: any[], programId: Address): Promise<Address<string>>;
export declare function lamportsToSol(lamports: bigint): string;
export declare function roundSol(sol: number): number;
export declare function zeroes(length: number): string;
export declare function solToLamports(sol: any): bigint;
export declare function safeMultiply(num0: number, num1: number): number;
export declare function sleep(ms: number): Promise<unknown>;
export declare function fnv32a(): number;
export declare function now(ms?: boolean): bigint;
export declare function parseSeconds(time: bigint): string;
export declare function parseMilliseconds(time: bigint): string;
export declare function isSameKey(key0: any, key1: any): boolean;
export declare function readStorage(key: string, defaultVal?: any): any;
export declare function writeStorage(key: string, value: any): void;
export declare function clearStorage(key: string): void;
