import { type Callback } from "./utils.js";
export declare const connectIsScheduled: import("svelte/store").Writable<boolean>;
export declare const disconnectIsScheduled: import("svelte/store").Writable<boolean>;
type Action = "connect" | "disconnect";
export declare function scheduleConnect(action: Action): void;
export declare const onDisconnect: {
    (callback: Callback): () => void;
    trigger: (...args: any[]) => Promise<void>;
    killAll: () => void;
};
export declare const onConnect: (callback: Callback, fireImmediatelyIfAlreadyConnected?: boolean) => () => void;
export declare function startConnectSchedule(): void;
export {};
