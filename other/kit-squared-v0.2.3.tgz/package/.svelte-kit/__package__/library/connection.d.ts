import { type Address, type Instruction, type TransactionSendingSigner } from '@solana/kit';
import type { NetworkType } from './wallet.js';
export declare function getNetworkType(): NetworkType | null;
export declare function init(http: string, ws: string, networkType?: NetworkType): void;
export declare function getNetwork(): {
    http: string | null;
    ws: string | null;
    networkType: NetworkType | null;
};
export declare function getConnection(): {
    rpc: import("@solana/kit").Rpc<import("@solana/kit").RequestAirdropApi & import("@solana/kit").GetAccountInfoApi & import("@solana/kit").GetBalanceApi & import("@solana/kit").GetBlockApi & import("@solana/kit").GetBlockCommitmentApi & import("@solana/kit").GetBlockHeightApi & import("@solana/kit").GetBlockProductionApi & import("@solana/kit").GetBlocksApi & import("@solana/kit").GetBlocksWithLimitApi & import("@solana/kit").GetBlockTimeApi & import("@solana/kit").GetClusterNodesApi & import("@solana/kit").GetEpochInfoApi & import("@solana/kit").GetEpochScheduleApi & import("@solana/kit").GetFeeForMessageApi & import("@solana/kit").GetFirstAvailableBlockApi & import("@solana/kit").GetGenesisHashApi & import("@solana/kit").GetHealthApi & import("@solana/kit").GetHighestSnapshotSlotApi & import("@solana/kit").GetIdentityApi & import("@solana/kit").GetInflationGovernorApi & import("@solana/kit").GetInflationRateApi & import("@solana/kit").GetInflationRewardApi & import("@solana/kit").GetLargestAccountsApi & import("@solana/kit").GetLatestBlockhashApi & import("@solana/kit").GetLeaderScheduleApi & import("@solana/kit").GetMaxRetransmitSlotApi & import("@solana/kit").GetMaxShredInsertSlotApi & import("@solana/kit").GetMinimumBalanceForRentExemptionApi & import("@solana/kit").GetMultipleAccountsApi & import("@solana/kit").GetProgramAccountsApi & import("@solana/kit").GetRecentPerformanceSamplesApi & import("@solana/kit").GetRecentPrioritizationFeesApi & import("@solana/kit").GetSignaturesForAddressApi & import("@solana/kit").GetSignatureStatusesApi & import("@solana/kit").GetSlotApi & import("@solana/kit").GetSlotLeaderApi & import("@solana/kit").GetSlotLeadersApi & import("@solana/kit").GetStakeMinimumDelegationApi & import("@solana/kit").GetSupplyApi & import("@solana/kit").GetTokenAccountBalanceApi & import("@solana/kit").GetTokenAccountsByDelegateApi & import("@solana/kit").GetTokenAccountsByOwnerApi & import("@solana/kit").GetTokenLargestAccountsApi & import("@solana/kit").GetTokenSupplyApi & import("@solana/kit").GetTransactionApi & import("@solana/kit").GetTransactionCountApi & import("@solana/kit").GetVersionApi & import("@solana/kit").GetVoteAccountsApi & import("@solana/kit").IsBlockhashValidApi & import("@solana/kit").MinimumLedgerSlotApi & import("@solana/kit").SendTransactionApi & import("@solana/kit").SimulateTransactionApi>;
    rpcSubscriptions: import("@solana/kit").RpcSubscriptions<import("@solana/rpc-subscriptions-api").SolanaRpcSubscriptionsApi>;
    getLamportBalance: (_address: any) => Promise<import("@solana/kit").PendingRpcRequest<Readonly<{
        context: Readonly<{
            slot: import("@solana/kit").Slot;
        }>;
        value: import("@solana/kit").Lamports;
    }>>>;
    sendTransactionFromInstructionsWithWalletApp: ({ feePayer, instructions, abortSignal }: {
        feePayer: TransactionSendingSigner;
        instructions: Array<Instruction>;
        abortSignal?: AbortSignal | null;
    }) => Promise<string>;
    getRecentSignatureConfirmation: (config: {
        abortSignal: AbortSignal;
        commitment: import("@solana/kit").Commitment;
        signature: import("@solana/kit").Signature;
    }) => Promise<void>;
};
export declare function checkAccountExists(address: Address): Promise<boolean>;
export declare function getAccountBalance(address: Address): Promise<bigint>;
