import type { WalletWithFeatures } from "@wallet-standard/base";
import { type StandardEventsFeature } from "@wallet-standard/features";
import type { UiWallet } from "@wallet-standard/ui";
type WalletMapElement = {
    wallet: WalletWithFeatures<StandardEventsFeature>;
    uiWallet: UiWallet;
};
export declare let availableWallets: string[];
export declare function recheckWallets(): void;
export declare let _selection: {
    selected: boolean;
    wallet: null | WalletMapElement;
    name: null | string;
};
export declare let selection: import("svelte/store").Writable<{
    selected: boolean;
    wallet: null | WalletMapElement;
    name: null | string;
}>;
export declare function clearSelectedVars(): void;
export declare const onSelectWallet: {
    (callback: import("./utils.js").Callback): () => void;
    trigger: (...args: any[]) => Promise<void>;
    killAll: () => void;
};
export declare function selectWallet(name: string): Promise<void>;
export declare function getWalletInfo(name: string): string;
export declare function expectWallet(name: string): void;
export declare function stopExpectWallet(): void;
export declare function unmountTeardown(): void;
export {};
