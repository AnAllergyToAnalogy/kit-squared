import { createSolanaRpcFromTransport, createSolanaRpcSubscriptions, createSolanaRpc, pipe, createTransactionMessage, appendTransactionMessageInstructions, setTransactionMessageFeePayerSigner, setTransactionMessageLifetimeUsingBlockhash, assertIsTransactionMessageWithSingleSendingSigner, signAndSendTransactionMessageWithSigners, getBase58Decoder, } from '@solana/kit';
import { createRecentSignatureConfirmationPromiseFactory } from '@solana/transaction-confirmation';
let rpcUrl = null;
let wsUrl = null;
let network = null;
export function getNetworkType() {
    return network;
}
export function init(http, ws, networkType = "mainnet") {
    rpcUrl = http;
    wsUrl = ws;
    network = networkType;
}
export function getNetwork() {
    return {
        http: rpcUrl,
        ws: wsUrl,
        networkType: network,
    };
}
function _checkNetwork() {
    if (!network)
        throw new Error("Network not configured. Must use configureNetwork to set rpc URLS and network type.");
}
function _connect() {
    _checkNetwork();
    const rpc = createSolanaRpc(rpcUrl);
    const rpcSubscriptions = createSolanaRpcSubscriptions(wsUrl);
    const getLamportBalance = async function (_address) {
        return rpc.getBalance(_address);
    };
    const signatureBytesToBase58String = (signatureBytes) => {
        return getBase58Decoder().decode(signatureBytes);
    };
    const sendTransactionFromInstructionsWithWalletAppFactory = (rpc) => {
        const sendTransactionFromInstructionsWithWalletApp = async ({ feePayer, instructions, abortSignal }) => {
            const { value: latestBlockhash } = await rpc.getLatestBlockhash().send({ abortSignal });
            const transactionMessage = pipe(createTransactionMessage({ version: 0 }), (message) => setTransactionMessageFeePayerSigner(feePayer, message), (message) => setTransactionMessageLifetimeUsingBlockhash(latestBlockhash, message), (message) => appendTransactionMessageInstructions(instructions, message));
            assertIsTransactionMessageWithSingleSendingSigner(transactionMessage);
            const signatureBytes = await signAndSendTransactionMessageWithSigners(transactionMessage);
            const signature = signatureBytesToBase58String(signatureBytes);
            return signature;
        };
        return sendTransactionFromInstructionsWithWalletApp;
    };
    const sendTransactionFromInstructionsWithWalletApp = sendTransactionFromInstructionsWithWalletAppFactory(rpc);
    const getRecentSignatureConfirmation = createRecentSignatureConfirmationPromiseFactory({ rpc, rpcSubscriptions });
    return {
        rpc,
        rpcSubscriptions,
        getLamportBalance,
        sendTransactionFromInstructionsWithWalletApp,
        getRecentSignatureConfirmation,
    };
}
export function getConnection() {
    if (!network)
        throw new Error("Network not configured (you must call setNetwork before this point).");
    return _connect();
}
// !!! TODO
export async function checkAccountExists(address) {
    // return true; 
    //todo: this
    return await getAccountBalance(address) > 0n;
}
export async function getAccountBalance(address) {
    return await (await getConnection().getLamportBalance(address)).value;
}
