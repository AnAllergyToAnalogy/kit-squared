import { type Callback } from "./utils.js";
import { type Address, type Instruction } from "@solana/kit";
import type { TransactionSendingSigner } from "@solana/signers";
export declare let _transacting: boolean;
export declare let transacting: import("svelte/store").Writable<boolean>;
export declare const TRANSACTION_STATE: {
    INITIAL: string;
    REQUESTED: string;
    PENDING: string;
};
export declare const transactionState: import("svelte/store").Writable<string>;
export declare const onTransaction: {
    request: {
        (callback: Callback): () => void;
        trigger: (...args: any[]) => Promise<void>;
        killAll: () => void;
    };
    submit: {
        (callback: Callback): () => void;
        trigger: (...args: any[]) => Promise<void>;
        killAll: () => void;
    };
    confirm: {
        (callback: Callback): () => void;
        trigger: (...args: any[]) => Promise<void>;
        killAll: () => void;
    };
    cancel: {
        (callback: Callback): () => void;
        trigger: (...args: any[]) => Promise<void>;
        killAll: () => void;
    };
    fail: {
        (callback: Callback): () => void;
        trigger: (...args: any[]) => Promise<void>;
        killAll: () => void;
    };
};
export declare function clearAddedAccounts(): void;
export declare function addAccounts(accounts: {
    [key: string]: Address;
}): void;
export declare function getAddedAccounts(): {
    [key: string]: Address;
};
export declare function transact(ixs?: Instruction[], names?: string[]): Promise<void>;
export declare function transactSingle(ix: Instruction, name?: string | null): Promise<void>;
export declare function createProgram(programClient: {
    [key: string]: any;
}, idl: {
    [key: string]: any;
}, signer?: null | TransactionSendingSigner, noEvents?: boolean): Promise<{
    [key: string]: any;
}>;
