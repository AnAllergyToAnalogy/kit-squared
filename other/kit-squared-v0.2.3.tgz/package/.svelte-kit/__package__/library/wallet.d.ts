import { type UiWallet, type UiWalletAccount } from "@wallet-standard/ui";
export declare const WALLET_STATE: {
    INITIAL: string;
    CONNECTING: string;
    CONNECTED: string;
    ERROR: string;
};
export declare let walletState: import("svelte/store").Writable<string>;
export declare const walletInitial: import("svelte/store").Readable<boolean>;
export declare const walletConnecting: import("svelte/store").Readable<boolean>;
export declare const walletConnected: import("svelte/store").Readable<boolean>;
export declare const walletError: import("svelte/store").Readable<boolean>;
export declare let signer: null | TransactionSendingSigner;
export declare let myKey: string | null;
export declare let me: import("svelte/store").Writable<string | null>;
export declare let myKeyString: string | null;
export type NetworkType = "mainnet" | "devnet" | "testnet";
export declare function isMe(address: any): boolean;
export declare function getStoredWalletSelection(): string | null;
export declare let connectedWalletAccount: UiWalletAccount | null;
export declare let hasConnectedWalletAccount: import("svelte/store").Writable<boolean>;
export declare let connectedWallet: UiWallet | null;
export declare let hasConnectedWallet: import("svelte/store").Writable<boolean>;
export declare function disconnectWallet(): Promise<void>;
import type { TransactionSendingSigner } from "@solana/signers";
export declare function initialiseWallet(): void;
export declare function unmountWallet(): void;
export declare const onWalletConnect: {
    (callback: import("./utils.js").Callback): () => void;
    trigger: (...args: any[]) => Promise<void>;
    killAll: () => void;
};
export declare const onWalletDisconnect: {
    (callback: import("./utils.js").Callback): () => void;
    trigger: (...args: any[]) => Promise<void>;
    killAll: () => void;
};
